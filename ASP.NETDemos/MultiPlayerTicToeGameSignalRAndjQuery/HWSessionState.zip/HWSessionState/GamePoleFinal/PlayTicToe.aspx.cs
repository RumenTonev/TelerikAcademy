﻿using HWSessionState.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HWSessionState.GamePoleFinal
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string v = Request.QueryString["id"];
            if (v == null)
            {
                Response.Redirect("~/Default");
                return;
            }
            UserManager manager = new UserManager();
            var user = manager.FindByNameAsync(HttpContext.Current.User.Identity.Name);
            var actuser = user.Result;
            manager.Dispose();
           // ApplicationUser appUser = actuser as ApplicationUser;
            Guid toComp=new Guid(v);
            using(ApplicationDbContext con=new ApplicationDbContext())
            {
                //con.Users.Attach(actuser);
                 var userbase= con.Users.Find(actuser.Id);

               Game elmt= con.Games.Find(toComp);
               if (elmt == null)
               {
                   //no such game
                   Response.Redirect("~/Default");
                   return;
               }
               else
               {
                   if(elmt.Partcipiants.Count==1)
                  {
                      if (elmt.Partcipiants.Any(x => x.Id == userbase.Id))
                      {
                          Response.Redirect("~/Default");
                          return;
                      }
                      else
                      {
                          elmt.Partcipiants.Add(userbase);
                          elmt.Status = Status.Closed;
                          con.SaveChanges();
                          
                      }
                  }
                   else if(elmt.Partcipiants.Count==0)
                   {
                       elmt.Partcipiants.Add(userbase);
                       elmt.Status = Status.Closed;
                       con.SaveChanges();
                   }
                  else 
                  {
                      Response.Redirect("~/Default");
                      return;
                  }

               }
               

            }
        }
    }
}